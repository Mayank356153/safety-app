package com.shee.safety;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
